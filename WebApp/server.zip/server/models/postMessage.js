import mongoose from 'mongoose';

const postSchema = mongoose.Schema({
    
    creator: String,
    selectedFile: String,
    createdAt: {
        type: Date,
        default: new Date(),
    },
    size: String,
    url: String,
    mushID: Object,
})

var PostMessage = mongoose.model('PostMessage', postSchema);

export default PostMessage;